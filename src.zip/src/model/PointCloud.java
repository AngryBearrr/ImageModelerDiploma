package model;

import java.util.List;

public class PointCloud {
    List<Point3D> points;
    Point3D transform;
    Point3D scale;
    Point3D rotation;
}
